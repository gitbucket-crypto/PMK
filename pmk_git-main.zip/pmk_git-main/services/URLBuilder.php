<?php
require_once '../autoload.php';

class URLBuilder
{
   public static  function  getURL(string $url)
   {
      if(str_contains(SITE_URL,APP_PORT))
      {
          static::$URL=SITE_URL.'/'.PROJECT.'/'.$url;
      }
      else
      {
          static::$URL=SITE_URL.':'.APP_PORT.'/'.PROJECT.'/'.$url;
      }
      return static::$URL; ob_end_flush();
   }

   public static  function  putURL(string $url)
   {
      if(str_contains(SITE_URL,APP_PORT))
      {
          static::$URL=SITE_URL.'/'.PROJECT.'/'.$url;
      }
      else
      {
          static::$URL=SITE_URL.':'.APP_PORT.'/'.PROJECT.'/'.$url;
      }
      return static::$URL; ob_end_flush();
   }

   protected static  $URL;
}

?>
