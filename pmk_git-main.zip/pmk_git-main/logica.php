<?php

$amostra =[20,65,682,1050,1558,4032,5065,5095,6063,15000];
$size = sizeof($amostra);

$i=0;
for( $i=0 ; $i<$size; $i++)
{
	if(($i+1)==$size)
	{
		//do nothing
	}	
	else
	{
		$res1 =((int)$amostra[$i+1]-$amostra[$i]);	
		if($res1%4===0)
		{
			echo 'amostras: ('.$amostra[$i+1].' - '.$amostra[$i].')/4  resta    '.($res1%4).'    <br/>';	
		}	
	
	}
}



?>
