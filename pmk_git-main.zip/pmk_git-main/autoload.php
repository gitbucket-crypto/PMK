<?php

ini_set("auto_detect_line_endings",true);
//=======================================
header('Access-Control-Allow-Origin: *');
//=======================================
header('Content-Type: *,charset=UTF-8');
//=======================================
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
//=======================================
header("Access-Control-Max-Age: 3600");
//=======================================
date_default_timezone_set("America/Sao_Paulo");
//=======================================
define('PROJECT','pmk');
//=======================================
define('APP_PORT',8080);
//=======================================
function siteURL()
{
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $domainName = $_SERVER['HTTP_HOST'];
    return $protocol.$domainName;
}
//=======================================
define( 'SITE_URL', siteURL() );
//=======================================
define('INTERNAL_ENDPOINT',SITE_URL.':'.APP_PORT.'/'.PROJECT);


debug(false);

function debug(bool $status)
{
    clearstatcache();
    if($status==true)
    {
        gc_collect_cycles();
        //========================================================
        ini_set('display_errors', true);
        //========================================================
        ini_set('display_startup_errors', true);
        //========================================================
        ini_set("auto_detect_line_endings",true);
        //========================================================
        ini_set('allow_url_open',true);
        //========================================================
        error_reporting(E_ALL);
    }
}

function loadModel($className)
{
    $dir =$_SERVER['DOCUMENT_ROOT'].'/'.PROJECT.'/'.'models/';
    $file = $dir. $className.'.php';

    if(file_exists($file))
    {
        require $file;
    }
}


function loadService($className)
{
    $dir =$_SERVER['DOCUMENT_ROOT'].'/'.PROJECT.'/'.'services/';
    $file = $dir. $className.'.php';

    if(file_exists($file))
    {
        require $file;
    }
}

function loadUtils($className)
{
    $dir =$_SERVER['DOCUMENT_ROOT'].'/'.PROJECT.'/'.'utils/';
    $file = $dir. $className.'.php';

    if(file_exists($file))
    {
        require $file;
    }
}

function loadAPI($className)
{
    $dir =$_SERVER['DOCUMENT_ROOT'].'/'.PROJECT.'/'.'api/';
    $file = $dir. $className.'.php';

    if(file_exists($file))
    {
        require $file;
    }
}



function loadRouter($className)
{
    $dir =$_SERVER['DOCUMENT_ROOT'].'/'.PROJECT.'/'.'router/';
    $file = $dir. $className.'.php';

    if(file_exists($file))
    {
        require $file;
    }
}

function loadDB($className)
{
    $dir =$_SERVER['DOCUMENT_ROOT'].'/'.PROJECT.'/'.'database/';
    $file = $dir. $className.'.php';

    if(file_exists($file))
    {
        require $file;
    }
}

function loadInterfaces($className)
{
    $dir =$_SERVER['DOCUMENT_ROOT'].'/'.PROJECT.'/'.'interfaces/';
    $file = $dir. $className.'.php';

    if(file_exists($file))
    {
        require $file;
    }
}


spl_autoload_register('loadModel');
spl_autoload_register('loadService');
spl_autoload_register('loadDB');
spl_autoload_register('loadUtils');
spl_autoload_register('loadAPI');
spl_autoload_register('loadRouter');
spl_autoload_register('loadInterfaces');




?>
