<?php
include_once '../autoload.php';
class PagamentoDebito
{
        function __contruct()
        {

        }

        public function setAgencia($agencia)
        {
            $this->agencia = $agencia;
        }

        public function setConta($conta)
        {
            $this->conta = $conta;
        }

        public function setBanco($banco)
        {
            $this->banco = $banco;
        }

        public function setCPF($acpf)
        {
            $this->CPF = $acpf;
        }

        public function getBanco()
        {
            return $this->banco;
        }

        public function getAgencia()
        {
            return $this->agencia;
        }

        public function getConta()
        {
            return $this->conta;
        }


        public function processaPagamento()
        {
            $dataDoacao = date('Y-m-d H:i:s');
            $db = new Database();
            $db->setDBAplience('MYSQL');
            $conn = $db->connect(false);
            $SQL="INSERT INTO doacao_x_debito (cpf, banco, agencia, conta, dataDoacao )
                    VALUES(:cpf, :banco, :agencia, :conta, :dataDoacao)";
            $stmt = $conn->prepare($SQL);
            $stmt->bindParam(':cpf', $this->CPF, PDO::PARAM_STR);
            $stmt->bindParam(':banco', $this->banco, PDO::PARAM_STR);
            $stmt->bindParam(':agencia', $this->agencia, PDO::PARAM_STR);
            $stmt->bindParam(':conta', $this->conta, PDO::PARAM_STR);
            $stmt->bindParam(':dataDoacao', $dataDoacao, PDO::PARAM_STR);
            return $stmt->execute()? TRUE : FALSE;
        }

        protected $agencia;
        protected $conta;
        protected $banco;
        protected $CPF;

}


?>
