<?php

include_once '../autoload.php';


$_put_raw= json_decode(trim(file_get_contents("php://input")),true);

//var_dump($_put_raw['body']); exit;
$doacao = new Doacao();
$doacao->setModalidade($_put_raw['body']['modalidade']);
$doacao->setTipo($_put_raw['body']['tipo']);
$doacao->setValor($_put_raw['body']['valor']);
$doacao->setDataDoacao($_put_raw['body']['dataC']);
$doacao->setCPF($_put_raw['body']["cpf"]);
$ok1 = $doacao->salvaDoacao();


$doador = new Doador();
$doador->setNome($_put_raw['body']["nome"]);
$doador->setCPF($_put_raw['body']["cpf"]);
$doador->setTelefone($_put_raw['body']["tel"]);
$doador->setNascimento($_put_raw['body']["dataN"]);
$doador->setCadastro($_put_raw['body']['dataC']);
$doador->setEndereco($_put_raw['body']['end']);
$doador->setCidade($_put_raw['body']['cidade']);
$doador->setEstado($_put_raw['body']['estado']);
$doador->setCEP($_put_raw['body']['cep']);
$doador->setModalidade($_put_raw['body']['modalidade']);
$ok2 =$doador->salvaDoador();

if($doacao->getTipo()=='debito')
{
    $pagto = new PagamentoDebito();
    $pagto->setBanco($_put_raw['body']["banco"]);
    $pagto->setAgencia($_put_raw['body']["agencia"]);
    $pagto->setConta($_put_raw['body']["conta"]);
    $pagto->setCPF($_put_raw['body']["cpf"]);
    $ok3=($pagto->processaPagamento());
}
if($doacao->getTipo()=='credito')
{
    $pagto = new PagamentoCredito();
    $pagto->setNome($_put_raw['body']["cardName"]);
    $pagto->setCPF($_put_raw['body']["cpf"]);
    $pagto->setNumero($_put_raw['body']["numero"]);
    $pagto->setCVV($_put_raw['body']["cvv"]);
    $pagto->setExpire($_put_raw['body']["expire"]);
    $ok3 =$pagto->processaPagamento();
}
if($ok1==true & $ok2==true && $ok3==true)
{
  echo json_encode(['Status'=>200,'msg'=>'Doação rezliada com sucesso']);die();
}
else echo json_encode(['Status'=>202,'msg'=>'Houve um erro por favor tente novamente mais tarde, obrigado']);die();


?>
