<?php
include_once '../autoload.php';


class PagamentoCredito
{
        function __contruct()
        {

        }

        public function setNome($anome)
        {
            $this->nome = $anome;
        }

        public function setCPF($acpf)
        {
            $this->CPF = $acpf;
        }

        public function setNumero($numero)
        {
            $this->numero = $numero;
        }

        public function setCVV($cvv)
        {
            $this->CVV = $cvv;
        }

        public function setExpire($expireData)
        {
            $this->expire = $expireData;
        }

        public function getNumero()
        {
            return $this->numero;
        }


        public function getNome()
        {
            return $this->nome;
        }

        public function getCPF()
        {
            return $this->CPF;
        }

        public function getCVV()
        {
            return $this->CVV;
        }

        public function getExpire()
        {
            return $this->expire;
        }


        public function processaPagamento()
        {
            $size =(int) strlen($this->getNumero()) -4;
            $inicio  = substr($this->getNumero(),0,6);
            $fim = substr($this->getNumero(),$size);

            $dataHoraCadastro = date('Y-m-d H:i:s');
            $db = new Database();
            $db->setDBAplience('MYSQL');
            $conn = $db->connect(false);
            $SQL="INSERT INTO doacao_x_cartao (cartao_nome, cartao_numero, cartao_index, cartao_last, CVV, expire, CPF, dataHoraCadastro)
                                      VALUES (:cartao_nome, :cartao_numero, :cartao_index, :cartao_last, :CVV, :expire, :CPF, :dataHoraCadastro  )";
            $stmt = $conn->prepare($SQL);
            $stmt->bindParam(':cartao_nome', $this->nome);
            $stmt->bindParam(':cartao_numero', $this->numero);
            $stmt->bindParam(':cartao_index', $inicio);
            $stmt->bindParam(':cartao_last', $fim);
            $stmt->bindParam(':CVV', $this->CVV);
            $stmt->bindParam(':expire', $this->expire);
            $stmt->bindParam(':CPF', $this->CPF);
            $stmt->bindParam(':dataHoraCadastro', $dataHoraCadastro);
            return $stmt->execute()? TRUE : FALSE;

        }

        protected $CVV;
        protected $numero;
        protected $expire;
        protected $nome;
        protected $CPF;
}

?>
