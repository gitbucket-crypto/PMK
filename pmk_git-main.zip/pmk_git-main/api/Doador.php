<?php
include_once '../autoload.php';

class Doador
{
    function __contruct()
    {

    }

    public function setNome($anome)
    {
        $this->nome = $anome;
    }

    public function setCPF($acpf)
    {
        $this->cpf = $acpf;
    }

    public function setTelefone($atel)
    {
        $this->telefone = $atel;
    }

    public function setNascimento($adtn)
    {
        $this->dataNascimento = $adtn;
    }

    public function setCadastro($adtc)
    {
        $this->dataCadastro = $adtc;
    }

    public function setEndereco($aend)
    {
        $this->endereco = $aend;
    }

    public function setCidade($acid)
    {
        $this->cidade = $acid;
    }


    public function setEstado($auf)
    {
      $this->estado = $auf;
    }

    public function setCEP($acep)
    {
        $this->cep = $acep;
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function getCPF()
    {
        return $this->cpf;
    }

    public function getTelefone()
    {
        return $this->telefone;
    }

    public function getdataNascimento()
    {
        return $this->dataNascimento;
    }

    public function getdataCadastro()
    {
        return $this->dataCadastro;
    }

    public function getEndereco()
    {
        return $this->endereco;
    }


    public function getCidade()
    {
        return $this->cidade;
    }

    public function getEstado()
    {
        return $this->estado;
    }

    public function getCEP()
    {
        return $this->cep;
    }

    public function getModalidade()
    {
        return $this->modalidade;
    }

    public function setModalidade($amod)
    {
        $this->modalidade =$amod;
    }


    public function salvaDoador()
    {
        $dataDoacao = date('Y-m-d H:i:s');
        $db = new Database();
        $db->setDBAplience('MYSQL');
        $conn = $db->connect(false);
        $SQL='INSERT INTO doador (nome,cpf,telefone,dataNascimento,dataCadastro,endereco,
                                  cidade,estado,cep,modalidade,dataDoacao)'.
              'VALUES (:nome, :cpf,:telefone,:dataNascimento,:dataCadastro,:endereco,
                        :cidade,:estado,:cep,:modalidade,:dataDoacao)';
        $stmt = $conn->prepare($SQL);
        $stmt->bindParam(':nome', $this->nome, PDO::PARAM_STR);
        $stmt->bindParam(':cpf', $this->cpf, PDO::PARAM_STR);
        $stmt->bindParam(':telefone', $this->telefone, PDO::PARAM_STR);
        $stmt->bindParam(':dataNascimento', $this->dataNascimento, PDO::PARAM_STR);
        $stmt->bindParam(':dataCadastro', $this->dataCadastro, PDO::PARAM_STR);
        $stmt->bindParam(':endereco', $this->endereco, PDO::PARAM_STR);
        $stmt->bindParam(':cidade', $this->cidade, PDO::PARAM_STR);
        $stmt->bindParam(':estado', $this->estado, PDO::PARAM_STR);
        $stmt->bindParam(':cep', $this->cep, PDO::PARAM_STR);
        $stmt->bindParam(':modalidade', $this->modalidade, PDO::PARAM_STR);
        $stmt->bindParam(':dataDoacao', $dataDoacao, PDO::PARAM_STR);
        return $stmt->execute()? TRUE : FALSE;

    }

    protected $modalidade;
    protected $nome;
    protected $cpf;
    protected $telefone;
    protected $dataNascimento;
    protected $dataCadastro;
    protected $endereco;
    protected $cidade;
    protected $estado;
    protected $cep;
}

?>
