<?php
require_once '../autoload.php';

$_get_raw = empty($_GET)? json_decode(trim(file_get_contents("php://input")),true):   null;

$cartaoNumero = $_get_raw['params']["cartaoNumber"];

$size =(int) strlen($cartaoNumero) -4;
$inicio  = substr($cartaoNumero,0,6);
$fim = substr($cartaoNumero,$size);

$db = new Database();
$db->setDBAplience('MYSQL');
$conn = $db->connect(false);

$resultSet= array();

$SQL='SELECT cartao_numero, cartao_index,cartao_last FROM  doacao_x_cartao WHERE cartao_index LIKE "%'.$inicio.'" AND cartao_last LIKE "%'.$fim.'"';

$stmt = $conn->prepare($SQL);
$stmt->execute();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $resultSet[] = $row;
}

if($resultSet[0]["cartao_numero"]==$cartaoNumero &
  $resultSet[0]["cartao_index"]==$inicio  &
  $resultSet[0]["cartao_last"]==$fim)
{
    echo json_encode(['Status'=>300,'msg'=>'Por favor entre em constato com o seu provisor, não foi possivel  cadastrar este cartão']); die();
}
else echo json_encode(['Status'=>200,'msg'=>'']); die();
?>
