<?php
include_once '../autoload.php';


class Doacao
{
    function __construct()
    {

    }


    public function setTipo($atipo)
    {
          $this->tipo=$atipo;
    }

    public function setValor($avalor)
    {
        $this->valor = $avalor;
    }

    public function setDataDoacao($adata)
    {
        $this->dataDoacao=$adata;
    }


    public function setModalidade($amod)
    {
        $this->modalidade =$amod;
    }

    public function getTipo()
    {
          return $this->tipo;
    }

    public function getValor()
    {
        return $this->valor;
    }

    public function getModalidade()
    {
        return $this->modalidade;
    }


    public function setDoador(Doador $doador)
    {
        $this->doador = $doador;
    }


    public function getDoador():Doador
    {
        return $this->doador;
    }

    public function setCPF($acpf)
    {
        $this->cpf = $acpf;
    }

    public function getCPF()
    {
        return $this->cpf;
    }


    public function salvaDoacao()
    {
          $db = new Database();
          $db->setDBAplience('MYSQL');
          $conn = $db->connect(false);
          $dataDoacao = date('Y-m-d H:i:s');
          $SQL="INSERT INTO doacao (cpf,valor,modalidade,tipoPagamento,dataDoacao) VALUES(:cpf,:valor,:modalidade,:tipoPagamento,:dataDoacao)";
          $stmt = $conn->prepare($SQL);
          $stmt->bindParam(':cpf', $this->cpf, PDO::PARAM_STR);
          $stmt->bindParam(':valor', $this->valor, PDO::PARAM_STR);
          $stmt->bindParam(':modalidade', $this->modalidade, PDO::PARAM_STR);
          $stmt->bindParam(':tipoPagamento', $this->tipo, PDO::PARAM_STR);
          $stmt->bindParam(':dataDoacao', $dataDoacao, PDO::PARAM_STR);
          return $stmt->execute()? TRUE : FALSE;
    }

    protected $cpf;
    protected $modalidade;
    protected $tipo; //debito ou crédito
    protected $valor;
    protected $dataDoacao;

}


?>
