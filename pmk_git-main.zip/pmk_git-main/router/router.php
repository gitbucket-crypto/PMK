<?php
include_once '../autoload.php';
ob_start();
$app = new HTTPRouter();



$app->any('/doacao', function($request, $response)
{
    $url = URLBuilder::putURL('api/APIDoacao.php');
    $response->send($url,$request,'PUT',200);
});


$app->get('/cartao',function ($request, $response)
{
    $url = URLBuilder::getURL('api/APIcartao.php');
    $response->send($url,$request,'GET',200);
});


$app->start();
?>
