-- MySQL dump 10.13  Distrib 5.5.62, for Win64 (AMD64)
--
-- Host: localhost    Database: catnorill
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doacao`
--

DROP TABLE IF EXISTS `doacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doacao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cpf` varchar(20) NOT NULL,
  `valor` varchar(120) NOT NULL,
  `modalidade` varchar(20) DEFAULT NULL,
  `tipoPagamento` varchar(20) DEFAULT NULL,
  `dataDoacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doacao`
--

LOCK TABLES `doacao` WRITE;
/*!40000 ALTER TABLE `doacao` DISABLE KEYS */;
INSERT INTO `doacao` VALUES (1,'012.345.678-90','134,55','unico','debito','2022-08-14 16:54:26'),(2,'012.345.678-90','134,55','unico','debito','2022-08-14 16:55:08'),(3,'012.345.678-90','134,55','unico','debito','2022-08-14 16:56:23'),(4,'012.345.678-90','134,55','unico','debito','2022-08-14 17:02:38'),(5,'012.345.678-90','134,55','unico','debito','2022-08-14 17:03:38'),(6,'012.345.678-90','134,55','unico','debito','2022-08-14 17:03:58'),(7,'012.345.678-90','134,55','unico','debito','2022-08-14 17:04:22'),(8,'012.345.678-90','134,55','unico','debito','2022-08-14 17:04:41'),(9,'012.345.678-90','134,55','unico','debito','2022-08-14 17:05:15'),(10,'012.345.678-90','134,55','unico','debito','2022-08-14 17:06:24'),(11,'012.345.678-90','134,55','unico','debito','2022-08-14 17:07:12'),(12,'012.345.678-90','134,55','unico','debito','2022-08-14 17:08:06'),(13,'012.345.678-90','134,55','unico','debito','2022-08-14 17:08:38'),(14,'012.345.678-90','134,55','unico','debito','2022-08-14 17:10:49'),(15,'012.345.678-90','134,55','unico','debito','2022-08-14 17:12:54'),(16,'012.345.678-90','134,55','unico','debito','2022-08-14 17:13:15'),(17,'012.345.678-90','134,55','unico','debito','2022-08-14 17:13:22'),(18,'012.345.678-90','134,55','unico','debito','2022-08-14 17:20:59'),(19,'012.345.678-90','134,55','unico','debito','2022-08-14 17:33:22'),(20,'012.345.678-90','134,55','undefined','debito','2022-08-14 17:33:31'),(21,'558.372.340-80','12,00','bimestral','credito','2022-08-14 17:40:10'),(22,'558.372.340-80','12,00','bimestral','credito','2022-08-14 17:41:49'),(23,'558.372.340-80','224,32','semestral','credito','2022-08-14 17:44:32'),(24,'558.372.340-80','224,32','semestral','credito','2022-08-14 17:47:42'),(25,'558.372.340-80','224,32','semestral','credito','2022-08-14 17:48:45'),(26,'558.372.340-80','224,32','semestral','credito','2022-08-14 17:49:52'),(27,'558.372.340-80','224,32','semestral','credito','2022-08-14 17:53:43'),(28,'558.372.340-80','224,32','semestral','credito','2022-08-14 17:58:02'),(29,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:01:23'),(30,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:04:02'),(31,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:04:49'),(32,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:05:59'),(33,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:06:26'),(34,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:07:04'),(35,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:07:27'),(36,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:08:06'),(37,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:10:50'),(38,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:13:33'),(39,'558.372.340-80','224,32','semestral','credito','2022-08-14 18:13:42');
/*!40000 ALTER TABLE `doacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doacao_x_cartao`
--

DROP TABLE IF EXISTS `doacao_x_cartao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doacao_x_cartao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cartao_nome` varchar(255) DEFAULT NULL,
  `cartao_numero` varchar(250) NOT NULL,
  `cartao_index` varchar(7) NOT NULL,
  `cartao_last` varchar(4) NOT NULL,
  `CVV` varchar(5) NOT NULL,
  `expire` varchar(7) NOT NULL,
  `CPF` varchar(16) NOT NULL,
  `dataHoraCadastro` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cartao_numero` (`cartao_numero`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doacao_x_cartao`
--

LOCK TABLES `doacao_x_cartao` WRITE;
/*!40000 ALTER TABLE `doacao_x_cartao` DISABLE KEYS */;
/*!40000 ALTER TABLE `doacao_x_cartao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doacao_x_debito`
--

DROP TABLE IF EXISTS `doacao_x_debito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doacao_x_debito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cpf` varchar(20) NOT NULL,
  `banco` varchar(120) NOT NULL,
  `agencia` varchar(120) NOT NULL,
  `conta` varchar(120) NOT NULL,
  `dataDoacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doacao_x_debito`
--

LOCK TABLES `doacao_x_debito` WRITE;
/*!40000 ALTER TABLE `doacao_x_debito` DISABLE KEYS */;
INSERT INTO `doacao_x_debito` VALUES (1,':cpf',':banco',':agencia',':conta','2022-08-14 17:11:54'),(2,'012.345.678-90','237 BRadesco','0232','23232','2022-08-14 17:12:54'),(3,'012.345.678-90','237 BRadesco','0232','23232','2022-08-14 17:13:15'),(4,'012.345.678-90','237 BRadesco','0232','23232','2022-08-14 17:13:22'),(5,'012.345.678-90','237 BRadesco','0232','23232','2022-08-14 17:20:59'),(6,'012.345.678-90','237 BRadesco','0232','23232','2022-08-14 17:33:22'),(7,'012.345.678-90','237 BRadesco','0232','23232','2022-08-14 17:33:31');
/*!40000 ALTER TABLE `doacao_x_debito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doador`
--

DROP TABLE IF EXISTS `doador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(12) NOT NULL,
  `dataNascimento` varchar(15) NOT NULL,
  `dataCadastro` varchar(15) NOT NULL,
  `endereco` varchar(250) NOT NULL,
  `cidade` varchar(250) NOT NULL,
  `estado` varchar(250) NOT NULL,
  `cep` varchar(12) NOT NULL,
  `modalidade` varchar(20) DEFAULT NULL,
  `dataDoacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doador`
--

LOCK TABLES `doador` WRITE;
/*!40000 ALTER TABLE `doador` DISABLE KEYS */;
INSERT INTO `doador` VALUES (1,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:02:38'),(2,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:03:38'),(3,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:03:58'),(4,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:04:22'),(5,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:04:41'),(6,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:05:15'),(7,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:06:24'),(8,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:07:12'),(9,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:08:06'),(10,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:08:38'),(11,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:10:49'),(12,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:12:54'),(13,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:13:15'),(14,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:13:22'),(15,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:20:59'),(16,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','unico','2022-08-14 17:33:22'),(17,'Pedro ','012.345.678-90','1139434','1990-02-04','14/08/2022','Rua Avanhaduva, 1034 casa4','São Paulo','SP','0434343','undefined','2022-08-14 17:33:31'),(18,'Pedro Kaluss','558.372.340-80','1123343434','1978-10-04','14/08/2022','Avenida Ipianga , 2242','São Paulo','SP','0435320','bimestral','2022-08-14 17:40:10'),(19,'Pedro Kaluss','558.372.340-80','1123343434','1978-10-04','14/08/2022','Avenida Ipianga , 2242','São Paulo','SP','0435320','bimestral','2022-08-14 17:41:49'),(20,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 17:44:32'),(21,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 17:47:42'),(22,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 17:48:45'),(23,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 17:49:52'),(24,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 17:53:43'),(25,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 17:58:02'),(26,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:01:23'),(27,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:04:02'),(28,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:04:49'),(29,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:05:59'),(30,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:06:26'),(31,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:07:04'),(32,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:07:27'),(33,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:08:06'),(34,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:10:50'),(35,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:13:33'),(36,'Pedro Klauss','558.372.340-80','1184384093','1988-10-08','','Avenida Ipiranga ,2392','São Paulo','São Paulo','030430493','semestral','2022-08-14 18:13:42');
/*!40000 ALTER TABLE `doador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'catnorill'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-14 20:26:31
