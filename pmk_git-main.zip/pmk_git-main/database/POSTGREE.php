<?php 

class POSTGREE
{
    private $host, $database_name, $username, $password,$port;

    public function setHost($host) {
        $this->host = $host; // localhost
    }

    public function setDatabase($database_name) {
        $this->database_name = $database_name; // database name
    }

    public function setUsermame($username) {
        $this->username = $username; // db username
    }

    public function setPassword($password) {
        $this->password = $password; // db password
    }

    public function setPort($port)
    {   
        $this->port = $port;
    }

    public function connect (bool $auto_commit) 
    {
       try{
            $con =(new PDO("phsql:host=".$this->host.';port='.$this->port.';dbname='.$this->database_name, $this->username, $this->password, array(PDO::ATTR_PERSISTENT => $auto_commit)));    
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT); 
            $con->query('SET NAMES utf8');
            $con->query('SET CHARACTER SET utf8');
            return $con;
       }
       catch ( PDOException $e )
        {
            echo 'Erro ao conectar com o PostGree: ' . $e->getMessage();
        }
    }
}


?>