<?php
require_once '../autoload.php';

class Database implements DBFactoryInterface
{
    protected $db_vendor;
    protected $host;
    protected $port;
    protected $username;
    protected $password;
    protected $database_name;
    protected $conn;

    function __construct()
    {

    }

    public function setDBAplience(string $db_vendor)
    {
        $this->db_vendor= $db_vendor;
    }

    public function setPort(int $port)
    {
        $this->port = $port; // port 3306
    }

    public function setHost($host) {
        $this->host = $host; // localhost
    }

    public function setDatabase($database_name) {
        $this->database_name = $database_name; // database name
    }

    public function setUsermame($username) {
        $this->username = $username; // db username
    }

    public function setPassword($password) {
        $this->password = $password; // db password
    }

    public function newFactory()
    {
        return new Database();
    }

    public function connect(bool $autocomit)
    {

        if($this->db_vendor=='MYSQL')
        {
            $DB =new MYSQL();
            $DB->setHost('localhost');
            $DB->setPort('3306');
            $DB->setDatabase('catNorill');
            $DB->setUsermame('dev_095');
            $DB->setPassword('fast9002');
            return $DB->connect($autocomit);
        }
        if($this->db_vendor=='POSTGREE')
        {
            $BD  = new POSTGREE();
            $DB->setHost('localhost');
            $DB->setPort('3306');
            $DB->setDatabase('catNorill');
            $DB->setUsermame('dev_095');
            $DB->setPassword('fast9002');
            return $DB->connect($autocomit);
        }
    }

    public function close($conn)
    {
        $conn = null;
    }
}

?>
