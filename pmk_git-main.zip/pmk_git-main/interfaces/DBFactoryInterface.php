<?php 

interface DBFactoryInterface
{
    public function setDBAplience(string $db_vendor);

    public function setPort(int $port);

    public function setHost($host);

    public function setDatabase($database_name);

    public function setUsermame($username);

    public function setPassword($password);

    public function newFactory();

    public function connect(bool $autocomit);

    public function close($conn);

}


?>